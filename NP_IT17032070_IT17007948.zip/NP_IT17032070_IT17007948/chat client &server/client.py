import socket
import select
import errno
import sys

H_LENGTH = 10

ip = "127.0.0.1"
port = 1234
my_uname = input("Enter Username: ")

# Create socket
# socket.AF_INET - address family, IPv4,
# socket.SOCK_STREAM - TCP, conection-based, socket.SOCK_DGRAM - UDP, connectionless, datagrams, socket.SOCK_RAW - raw IP packets
c_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Establish connection to a given ip and port
c_socket.connect((ip, port))

#Connection set to non-blocking state,
# so .recv() call won't block,exception returned
c_socket.setblocking(False)

# Prepare username and header and send them
# encode username to bytes, prepare header of fixed size, again encode that to bytes
un = my_uname.encode('utf-8')
un_header = f"{len(un):<{H_LENGTH}}".encode('utf-8')
c_socket.send(un_header + un)

while True:
    # user inputs message
    msg = input(f'{my_uname} > ')

    # If message not empty
    if msg:
        # Message encoded to bytes, prepare header and convert to bytes and send (similiar to username)
        msg = msg.encode('utf-8')
        msg_header = f"{len(msg):<{H_LENGTH}}".encode('utf-8')
        c_socket.send(msg_header + msg)

    try:
        # loop over received messages and print them
        while True:

            # Receive the "header" containing length of username, size is defined and constant
            un_header = c_socket.recv(H_LENGTH)

            #if no data recieved server closes connection , eg: -socket.close() or socket.shutdown()
            if not len(un_header):
                print('Connection closed by the server')
                sys.exit()

            # header to int value conversion
            un_length = int(un_header.decode('utf-8').strip())

            # Receive and decode username
            username = c_socket.recv(un_length).decode('utf-8')

            # Same process is done for message
            msg_header = c_socket.recv(H_LENGTH)
            msg_length = int(msg_header.decode('utf-8').strip())
            message = c_socket.recv(msg_length).decode('utf-8')

            print(f'{username} > {message}')

    except IOError as e:
        #When incoming data is null an error is raised , some operating system will indicate the error using AGAIN or some using WOULDBLOCK
        # error code.Both conditions are checked here , if one of those errors continue as normal else if different error comes up
        # something has happened.
        if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
            print('Error: {}'.format(str(e)))
            sys.exit()

        continue

    except Exception as e:
        # Exception, exit
        print('Error: '.format(str(e)))
        sys.exit()