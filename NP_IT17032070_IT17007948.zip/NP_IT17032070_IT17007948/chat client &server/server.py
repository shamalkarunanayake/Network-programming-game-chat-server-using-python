import socket
import select

H_LENGTH = 10

ip = "127.0.0.1"
port = 1234

# Create a socket
s_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# SO_ - socket option
# SOL_ - socket option level
# Sets REUSEADDR (as a socket option) to 1 on socket
s_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

s_socket.bind((ip, port))

# server listen to new connections
s_socket.listen()

# socket list for select.select()
sockets_list = [s_socket]

# List of connected clients
clients = {}

print(f'Listening for connections on {ip}:{port}...')

# Handles message receiving
def receive_message(client_socket):

    try:

        msg_header = client_socket.recv(H_LENGTH)

        if not len(msg_header):
            return False

        # Convertion of header to int value
        msg_length = int(msg_header.decode('utf-8').strip())

        # Return object of message header and message data
        return {'header': msg_header, 'data': client_socket.recv(msg_length)}

    except:
        #client connection closed
        return False

while True:

    # Calls Unix select() system call or Windows select() WinSock call with three parameters:
    #   - rlist - sockets monitorincoming data
    #   - wlist - sockets for data to be send to
    #   - xlist - sockets to be monitored for exceptions
    # Returns lists:
    #   - reading - sockets we received some data on
    #   - writing - sockets ready for data to be send through them
    #   - errors  - sockets with some exceptions
    # This is a blocking call, code execution will "wait" here and "get" notified in case any action should be taken
    read_sockets, _, exception_sockets = select.select(sockets_list, [], sockets_list)


    # Iterate over notified sockets
    for notified_socket in read_sockets:

        # If notified socket is a server socket - new connection
        if notified_socket == s_socket:

            # Accept new connection
            client_socket, client_address = s_socket.accept()

            # Client should send his name right away, receive it
            user = receive_message(client_socket)

            # If False - client disconnected
            if user is False:
                continue

            # Add accepted socket to select.select() list
            sockets_list.append(client_socket)

            # Also save username and username header
            clients[client_socket] = user

            print('Accepted new connection from {}:{}, username: {}'.format(*client_address, user['data'].decode('utf-8')))

        # Else existing socket is sending a message
        else:

            # Receive message
            message = receive_message(notified_socket)

            # If False, client disconnected
            if message is False:
                print('Closed connection from: {}'.format(clients[notified_socket]['data'].decode('utf-8')))

                # Remove from list for socket.socket()
                sockets_list.remove(notified_socket)

                # Remove from our list of users
                del clients[notified_socket]

                continue

            # Get user by notified socket, so we will know who sent the message
            user = clients[notified_socket]

            print(f'Received message from {user["data"].decode("utf-8")}: {message["data"].decode("utf-8")}')

            # Iterate over connected clients and broadcast message
            for client_socket in clients:

                # But don't sent it to sender
                if client_socket != notified_socket:

                    # Send user and message (both with their headers)
                    client_socket.send(user['header'] + user['data'] + message['header'] + message['data'])

    # handle some socket exceptions
    for notified_socket in exception_sockets:

        # Remove from the list for socket.socket()
        sockets_list.remove(notified_socket)

        # Remove from our list of users
        del clients[notified_socket]