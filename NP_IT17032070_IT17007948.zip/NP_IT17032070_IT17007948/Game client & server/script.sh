#!/bin/bash
python3 /home/mala/Desktop/chat/client.py
